    $domainUserName = 'vcloud-lab\vjanvi'
    $domainPassword = 'Computer@123'
    
    # create secure string from plain-text string
    $secureString = ConvertTo-SecureString -AsPlainText -Force -String $domainPassword -ErrorAction SilentlyContinue
    $error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log -Append
    # convert secure string to encrypted string (for safe-ish storage to config/file/etc.)
    $encryptedString = ConvertFrom-SecureString -SecureString $secureString -ErrorAction SilentlyContinue
    $error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log -Append
    # convert encrypted string back to secure string
    $secureString = ConvertTo-SecureString -String $encryptedString -ErrorAction SilentlyContinue
    $error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log -Append
    # use secure string to create credential object
    $credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $domainUserName,$secureString -ErrorAction SilentlyContinue
    $error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log -Append
    Add-Computer -DomainName vcloud-lab.com -Credential $credential -Restart -Force -ErrorAction SilentlyContinue
    $error[0].Exception.Message | Out-File -FilePath c:\temp\errors.log -Append