$terraformPath = 'C:\Users\demir\OneDrive\Script\Ritesh_vmware\Terraform\Terraform_vCenter_VMClone_Fixed_Firmware_and_DomainJoin'
$fileName = 'dev_vms.csv'
$localTemplateAdmin = 'localadmin'
$localTemplatePassword = 'Computer@123'
$domain = "vcloud-lab.com"
$domainUserName = 'vjanvi'
$domainPassword = 'Computer@123'

Set-Location -Path $terraformPath 

#execute Terraform
Write-Host "Clone systems"
#terraform workspace select policy
terraform plan -var="filename=$fileName"
terraform apply -var="filename=$fileName" --auto-approve

$secureString = ConvertTo-SecureString -AsPlainText -Force -String $localTemplatePassword
$encryptedString = ConvertFrom-SecureString -SecureString $secureString
$secureString = ConvertTo-SecureString -String $encryptedString
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $localTemplateAdmin,$secureString

$windowsServers = Import-CSV $PSScriptRoot\$fileName | Where-Object {$_.os -eq 'Windows'}

Write-Host 'Join domain into system'
$psSession = New-PSSession -ComputerName $windowsServers.ipv4_address -Credential $credential

Invoke-Command -Session $psSession -ScriptBlock {
    Write-Host 'Disable IPv6'
    Disable-NetAdapterBinding -Name 'Ethernet0' -ComponentID 'ms_tcpip6'
    Write-Host 'Flush DNS'
    ipconfig /flushdns
    Write-Host 'Join domain into domain'
    netdom join $env:ComputerName /Domain:$($args[0]) /UserD:$($args[1]) /PasswordD:$($args[2]) /REBoot
    Write-Host 'Set administrator password'
    net user Administrator Computer@123
} -ArgumentList $domain, $domainUserName, $domainPassword