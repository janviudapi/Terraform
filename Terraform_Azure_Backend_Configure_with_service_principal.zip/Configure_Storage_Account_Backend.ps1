######### Run once to login to Azure ##########
<#
Import-Module Az
Connect-AzAccount -Subscription Sponsership-by-Microsoft
Select-AzContext
#>

######### Update Below Values ##########

$resourceGroupName = 'vcloud-lab.com'
$storageAccountName = 'vcloudlabterraform'
$storageAccountSku = 'Standard_LRS'
$blobContainerName = 'tfstate'

#$storageAccountUser = 'janvi@vcloud-lab.com'
$roleDefinition = 'Storage Blob Data Owner'
$servicePrincipalName = 'tfapp'

#Get-AzRoleDefinition | where-object {$_.Name -match 'blob'} | Select-Object Name, Id, Description
<#
Name                          Id                                   Description
----                          --                                   -----------
Storage Blob Data Contributor ba92xxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx Allows for read, write and delete access to Azure Storage blob containers and data
Storage Blob Data Owner       b7e6xxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx Allows for full access to Azure Storage blob containers and data, including assigning POSIX access control.
Storage Blob Data Reader      2a2bxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx Allows for read access to Azure Storage blob containers and data
Storage Blob Delegator        db58xxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx Allows for generation of a user delegation key which can be used to sign SAS tokens
#>

######### Do not touch below code ##########

try 
{
    $resourceGroup = Get-AzResourceGroup -Name $resourceGroupName -ErrorAction Stop
    "Found Existing Resource Group - $($resourceGroup.ResourceGroupName)"
    $storageAccount = New-AzStorageAccount -Name $storageAccountName -Location $resourceGroup.Location -ResourceGroupName $resourceGroup.ResourceGroupName -SkuName $storageAccountSku -ErrorAction Stop
    "Storage Account created - $($storageAccount.StorageAccountName)"
    $storageAccountContext = New-AzStorageContext -StorageAccountName $storageAccount.StorageAccountName -ErrorAction Stop
    $blobContainer = New-AzStorageContainer -Name $blobContainerName -Context $storageAccountContext -ErrorAction Stop
    "Blob Container created - $($blobContainer.Name)"


    $servicePrincipal = New-AzADServicePrincipal -DisplayName $servicePrincipalName
    "Service Principal created - $($servicePrincipal.DisplayName)"
    #New-AzADServicePrincipalCredential #Create new SP credential secret
    
    #Assign role assignment to ad user
    #$roleAssignment = New-AzRoleAssignment -SignInName $user.DisplayName -RoleDefinitionName $roleDefinition -Scope $storageAccount.Id  -ErrorAction Stop
    #New-AzADServicePrincipalAppRoleAssignment   
    $roleAssignment = New-AzRoleAssignment -ApplicationId $servicePrincipal.AppId -Scope $storageAccount.Id -RoleDefinitionName $roleDefinition
    "Role Assigned to Service Principal over Storage Account - $($roleAssignment.RoleAssignmentName)"

    $azContext = Get-AzContext

    #"{0,-20} = {1,-42} {2}" -f 'resource_group_name', $($resourceGroup.ResourceGroupName), '# Can be passed via `-backend-config=`"resource_group_name=<resource group name>"` in the `init` command.'
    $tfScript = "{0,-20} = `"{1,-42} {2}`n" -f 'resource_group_name', "$($resourceGroup.ResourceGroupName)`"", '# Can be passed via `-backend-config=`"resource_group_name=<resource group name>"` in the `init` command.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'storage_account_name', "$($storageAccount.StorageAccountName)`"", '# Can be passed via `-backend-config=`"storage_account_name=<storage account name>"` in the `init` command.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'container_name', "$($blobContainer.Name)`"",  '# Can be passed via `-backend-config=`"container_name=<container name>"` in the `init` command.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'key', 'example.terraform.tfstate"', '# Can be passed via `-backend-config=`"key=<blob key name>"` in the `init` command.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'client_id', "$($servicePrincipal.Id)`"", '# Can also be set via `ARM_CLIENT_ID` environment variable.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'client_secret', "$($servicePrincipal.PasswordCredentials.SecretText)`"", '# Can also be set via `ARM_CLIENT_SECRET` environment variable.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}`n" -f 'subscription_id', "$($azContext.Subscription)`"", '# Can also be set via `ARM_SUBSCRIPTION_ID` environment variable.'
    $tfScript += "    {0,-20} = `"{1,-42} {2}" -f 'tenant_id', "$($azContext.Tenant)`"", '# Can also be set via `ARM_TENANT_ID` environment variable.'

$terraformBackEndConf = @"
`n
`n
`e[41m##############################################################################################################`e[0m
`e[41m##       Use Below configuration in your Terraform file to configure Azure Storage Account Backend.         ##`e[0m
`e[41m##############################################################################################################`e[0m
`e[44m##################################################   Start   #################################################`e[0m

terraform {
  backend "azurerm" {
    $tfScript
  }
}

`e[44m##################################################   End   ##################################################`e[0m
`n
`n
"@
$terraformBackEndConf
}
catch 
{
    Write-Error $Error[0].Exception.Message
}

<#
#Delete reosource for testing
Remove-AzStorageAccount -Name $storageAccountName -ResourceGroupName $resourceGroupName -Force
Remove-AzADServicePrincipal -ApplicationId $servicePrincipal.AppId # -ServicePrincipalName $ServicePrincipal.ServicePrincipalName
#>